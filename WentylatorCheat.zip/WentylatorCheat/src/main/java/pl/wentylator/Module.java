package pl.wentylator;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name, category, desc;
    public boolean enabled;
    public final List<Setting> settings = new ArrayList<>();

    public Module(String name, String category, String desc) {
        this.name = name; this.category = category; this.desc = desc;
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient mc) {}

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    protected Setting add(String n, double v, double min, double max, double step) {
        Setting s = new Setting(n, v, min, max, step);
        settings.add(s);
        return s;
    }

    public static class Setting {
        public final String name;
        public double value;
        public final double min, max, step;
        public Setting(String name, double value, double min, double max, double step) {
            this.name = name; this.value = value; this.min = min; this.max = max; this.step = step;
        }
        public void cycle() {
            value += step;
            if (value > max + 1e-9) value = min;
        }
    }
}
