package pl.wentylator;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final String[] CATS = {"Combat", "Visual", "Movement"};
    private static final int[] CAT_COLORS = {0xFFE74C3C, 0xFF3498DB, 0xFF2ECC71};
    private static final int W = 130, ROW = 24;

    public ClickGuiScreen() { super(Text.literal("WentylatorCheat")); }

    @Override public boolean shouldPause() { return false; }

    private int panelX(int i) { return width / 2 - (CATS.length * (W + 10)) / 2 + i * (W + 10); }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0x99000000);
        g.drawCenteredTextWithShadow(textRenderer, "§b§lWentylatorCheat §7| L - zamknij | LPM wlacz | PPM zmien opcje", width / 2, 12, 0xFFFFFF);

        for (int c = 0; c < CATS.length; c++) {
            int x = panelX(c), y = 40;
            List<Module> mods = byCat(CATS[c]);
            g.fill(x, y, x + W, y + 20, CAT_COLORS[c]);
            g.drawTextWithShadow(textRenderer, "§l" + CATS[c], x + 8, y + 6, 0xFFFFFF);
            y += 20;
            for (Module m : mods) {
                boolean hover = mx >= x && mx <= x + W && my >= y && my < y + ROW;
                int bg = m.enabled ? (CAT_COLORS[c] & 0x00FFFFFF) | 0xCC000000 : (hover ? 0xEE333333 : 0xEE1A1A1A);
                g.fill(x, y, x + W, y + ROW, bg);
                // ikonka: kolorowy kwadrat z pierwsza litera
                g.fill(x + 3, y + 4, x + 19, y + 20, CAT_COLORS[c]);
                g.drawCenteredTextWithShadow(textRenderer, m.name.substring(0, 1), x + 11, y + 8, 0xFFFFFF);
                g.drawTextWithShadow(textRenderer, m.name, x + 24, y + 4, m.enabled ? 0xFFFFFF : 0xAAAAAA);
                String sub = m.settings.isEmpty() ? (m.enabled ? "ON" : "OFF")
                        : m.settings.get(0).name + ": " + fmt(m.settings.get(0).value);
                g.drawTextWithShadow(textRenderer, "§7" + sub, x + 24, y + 14, 0xFFFFFF);
                g.fill(x + W - 6, y + 8, x + W - 2, y + 16, m.enabled ? 0xFF2ECC71 : 0xFFE74C3C);
                if (hover) g.drawTooltip(textRenderer, Text.literal(m.desc), mx, my);
                y += ROW;
            }
        }
    }

    private String fmt(double v) { return v == Math.floor(v) ? String.valueOf((int) v) : String.format("%.1f", v); }

    private List<Module> byCat(String cat) {
        List<Module> r = new ArrayList<>();
        for (Module m : Modules.ALL) if (m.category.equals(cat)) r.add(m);
        return r;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int c = 0; c < CATS.length; c++) {
            int x = panelX(c), y = 60;
            for (Module m : byCat(CATS[c])) {
                if (mx >= x && mx <= x + W && my >= y && my < y + ROW) {
                    if (button == 0) m.toggle();
                    else if (button == 1 && !m.settings.isEmpty()) m.settings.get(0).cycle();
                    return true;
                }
                y += ROW;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (WentylatorCheat.menuKey.matchesKey(key, scan)) { close(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
