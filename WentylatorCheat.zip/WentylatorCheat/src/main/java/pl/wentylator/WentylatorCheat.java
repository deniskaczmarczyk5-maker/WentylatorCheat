package pl.wentylator;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class WentylatorCheat implements ClientModInitializer {
    public static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        Modules.init();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Kliknij L aby otworzyc Menu Cheatow", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_L, "WentylatorCheat"));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new ClickGuiScreen());
            }
            if (mc.player == null || mc.world == null) return;
            for (Module m : Modules.ALL) if (m.enabled) m.onTick(mc);
        });
    }
}
