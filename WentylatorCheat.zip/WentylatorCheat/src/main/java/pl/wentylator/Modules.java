package pl.wentylator;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public class Modules {
    public static final List<Module> ALL = new ArrayList<>();

    public static void init() {
        ALL.add(new KillAura());
        ALL.add(new AimAssist());
        ALL.add(new TriggerBot());
        ALL.add(new AutoWeb());
        ALL.add(new FullBox());
        ALL.add(new Fullbright());
        ALL.add(new Sprint());
        ALL.add(new NoFall());
    }

    /** Najblizszy zywy cel (gracze) w zasiegu. */
    static LivingEntity nearest(MinecraftClient mc, double range) {
        ClientPlayerEntity me = mc.player;
        LivingEntity best = null;
        double bestD = range * range;
        for (Entity e : mc.world.getEntities()) {
            if (e == me || !(e instanceof PlayerEntity p) || !p.isAlive()) continue;
            double d = me.squaredDistanceTo(e);
            if (d < bestD) { bestD = d; best = p; }
        }
        return best;
    }

    static void lookAt(ClientPlayerEntity me, Entity t, float smooth) {
        Vec3d eye = me.getEyePos();
        Vec3d to = t.getPos().add(0, t.getHeight() * 0.85, 0).subtract(eye);
        double flat = Math.sqrt(to.x * to.x + to.z * to.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90f);
        float pitch = (float) -Math.toDegrees(Math.atan2(to.y, flat));
        me.setYaw(me.getYaw() + MathHelper.wrapDegrees(yaw - me.getYaw()) / smooth);
        me.setPitch(MathHelper.clamp(me.getPitch() + (pitch - me.getPitch()) / smooth, -90f, 90f));
    }

    // ---------- COMBAT ----------
    static class KillAura extends Module {
        Setting range = add("Zasieg", 3.5, 2.0, 6.0, 0.5);
        Setting cps = add("Cooldown", 0.9, 0.5, 1.0, 0.1);
        KillAura() { super("KillAura", "Combat", "Automatycznie bije najblizszego gracza"); }
        @Override public void onTick(MinecraftClient mc) {
            LivingEntity t = nearest(mc, range.value);
            if (t == null || mc.player.getAttackCooldownProgress(0.5f) < cps.value) return;
            mc.interactionManager.attackEntity(mc.player, t);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    static class AimAssist extends Module {
        Setting range = add("Zasieg", 5.0, 2.0, 8.0, 0.5);
        Setting smooth = add("Plynnosc", 6.0, 1.0, 15.0, 1.0);
        AimAssist() { super("AimAssist", "Combat", "Plynnie naprowadza celownik na gracza"); }
        @Override public void onTick(MinecraftClient mc) {
            LivingEntity t = nearest(mc, range.value);
            if (t != null) lookAt(mc.player, t, (float) smooth.value);
        }
    }

    static class TriggerBot extends Module {
        TriggerBot() { super("TriggerBot", "Combat", "Bije gdy celownik jest na graczu"); }
        @Override public void onTick(MinecraftClient mc) {
            if (mc.crosshairTarget instanceof EntityHitResult r && r.getEntity() instanceof PlayerEntity
                    && mc.player.getAttackCooldownProgress(0.5f) >= 0.95f) {
                mc.interactionManager.attackEntity(mc.player, r.getEntity());
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }

    static class AutoWeb extends Module {
        Setting range = add("Zasieg", 4.0, 2.0, 6.0, 0.5);
        int cd;
        AutoWeb() { super("AutoWeb", "Combat", "Stawia pajeczyne pod celem"); }
        @Override public void onTick(MinecraftClient mc) {
            if (cd-- > 0) return;
            LivingEntity t = nearest(mc, range.value);
            if (t == null) return;
            int slot = -1;
            for (int i = 0; i < 9; i++)
                if (mc.player.getInventory().getStack(i).isOf(Items.COBWEB)) { slot = i; break; }
            BlockPos feet = t.getBlockPos();
            if (slot < 0 || !mc.world.getBlockState(feet).isAir()) return;
            int old = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = slot;
            BlockPos below = feet.down();
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                    new BlockHitResult(Vec3d.ofCenter(below), Direction.UP, below, false));
            mc.player.getInventory().selectedSlot = old;
            cd = 10;
        }
    }

    // ---------- VISUAL ----------
    static class FullBox extends Module {
        FullBox() { super("FullBox", "Visual", "Podswietla graczy przez sciany (glow)"); }
        @Override public void onTick(MinecraftClient mc) {
            for (Entity e : mc.world.getEntities())
                if (e instanceof PlayerEntity && e != mc.player) e.setGlowing(true);
        }
        @Override public void onDisable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.world != null) for (Entity e : mc.world.getEntities()) e.setGlowing(false);
        }
    }

    static class Fullbright extends Module {
        Fullbright() { super("Fullbright", "Visual", "Widzenie w ciemnosci"); }
        @Override public void onTick(MinecraftClient mc) {
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false));
        }
        @Override public void onDisable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    // ---------- MOVEMENT ----------
    static class Sprint extends Module {
        Sprint() { super("Sprint", "Movement", "Zawsze sprintuje do przodu"); }
        @Override public void onTick(MinecraftClient mc) {
            if (mc.options.forwardKey.isPressed() && !mc.player.horizontalCollision) mc.player.setSprinting(true);
        }
    }

    static class NoFall extends Module {
        NoFall() { super("NoFall", "Movement", "Brak obrazen od upadku"); }
        @Override public void onTick(MinecraftClient mc) {
            if (mc.player.fallDistance > 2f)
                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, mc.player.horizontalCollision));
        }
    }
}
